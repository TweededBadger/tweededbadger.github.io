(function() {
    var testingUtils = {};
    this.testingUtils = testingUtils;
    testingUtils.randomLatLng = function() {
        var latlng = new google.maps.LatLng(getRandomInRange(51, 53, 3),getRandomInRange(-2.3, 0.34, 3));
        return latlng;
    }
    function getRandomInRange(from, to, fixed) {
        return (Math.random() * (to - from) + from).toFixed(fixed) * 1;
        // .toFixed() returns string, so ' * 1' is a trick to convert to number
    }
})(this);
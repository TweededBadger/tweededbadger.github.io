
define([
    'require',
    'angular',
    'css!../css/main.min',
    'app',
    'routes'
], function (require, ng) {
    'use strict';
    require(['domReady!'], function (document) {
        ng.bootstrap(document, ['SpeedtestApp']);
        console.log("Speedtest v0.92");
    });
});

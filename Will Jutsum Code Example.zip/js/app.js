define([
    'angular',
    'angular-route',
    'angular-cookies',
    'view_speedtest',
    './directives/index',
    './filters/index',
    './services/index',
    'jquery',
    'bootstrapjs'
], function (angular) {
'use strict';
return angular.module('SpeedtestApp', [
  'SpeedtestApp.view_speedtest',
    'speedTestDirectives',
    'speedTestServices',
    'speedtestFilters',
    'ngRoute',
    'ngCookies'
])

});





define(['./module', 'svg-pan-zoom', 'county_data'], function (directives, svgPanZoom) {
    'use strict';
    directives.directive('mapModule',
        ['optionsService', '$timeout', '$compile', '$resource', '$parse','$window',
            'SpeedtestAverageFilter',
            function (optionsService, $timeout, $compile, $resource, $parse,$window, SpeedtestAverageFilter) {
                return {
                    restrict: 'A',
//            scope:true,
                    templateUrl: optionsService.assetUrl + "templates/map_module.html",
                    link: function (scope, element, attrs) {

                        scope.county_data = county_data;
                        $timeout(function () {
                            scope.zoomMap = svgPanZoom('#map-svg', {
                                zoomEnabled: true,
                                controlIconsEnabled: true,
                                fit: true,
                                center: true
                            });
                            scope.mapReady = true;
                        }, 10);

                        scope.$watch(function(){
                            return $window.innerWidth;
                        }, function(value) {
                            console.log(value);
                        });

                        $window.onresize = function() {
                            if (scope.mapReady) {
                                scope.zoomMap.resize();
                            }
                        }

                        var gradesResource = $resource(optionsService.apiUrl + '/grades');
                        scope.grades = gradesResource.query();
                        scope.speedData = SpeedtestAverageFilter.query(
                            {order_by: 'county'
                            }, function (data) {

                            });

                        scope.testFunc = function(c) {
                            console.log("test");
                            console.log(c);
//                            var myEl = angular.element( document.querySelector( '#county'+ c.id ) );
//                            console.log(myEl);
                        }
                        var providersResource = $resource(optionsService.apiUrl + '/providers///');
                        scope.providers = providersResource.query(function (d) {
                            scope.providers.unshift({
                                id: 0,
                                provider_approved: true,
                                provider_isp: "",
                                provider_logo: "logo-all",
                                provider_name: "all",
                                provider_type: "cellular"
                            })
                            console.log(scope.providers);
                        });
                        scope.chosenProvider;
                        scope.chooseMapProvider = function (provider) {
                            scope.chosenProvider = provider;

                            if (provider.id == 0) {
                                scope.speedData = SpeedtestAverageFilter.query(
                                    {order_by: 'county'
                                    }, function (data) {

                                    });
                            } else {
                                scope.speedData = SpeedtestAverageFilter.query(
                                    {order_by: 'county', arg1: '/' + provider.id
                                    }, function (data) {
                                    });
                            }

                        }
                    }
                }
            }]).directive('mapPath',['$parse',function($parse){
            return {
                restrict: 'A',
                link: function (scope, element, attrs) {
                    var regionClickFunction = $parse(attrs.regionClickFunction);
                    var countyMouseDownEvent;
                    scope.regionMouseUp = function (e, data) {
                        console.log(e);
                        console.log(countyMouseDownEvent);
                        if (e.type == "touchend") {
                            if (countyMouseDownEvent.changedTouches[0].screenX == e.changedTouches[0].screenX
                                && countyMouseDownEvent.changedTouches[0].screenY == e.changedTouches[0].screenY) {
                                regionClickFunction(scope, {data: scope.county});
                            }
                        } else if (countyMouseDownEvent.x == e.x && countyMouseDownEvent.y == e.y) {
                            regionClickFunction(scope, {data: scope.county});
                        }
                    }
                    scope.regionMouseDown = function (e, data) {
                        countyMouseDownEvent = e;
                    }
                    scope.register = function(c) {
                        console.log(c);
                    }
                    element[0].addEventListener("touchstart", scope.regionMouseDown, false);
                    element[0].addEventListener("touchend", scope.regionMouseUp, false);
                }
            }
        }]) ;

    function makeSVG(tag, attrs) {
        var el = document.createElementNS('http://www.w3.org/2000/svg', tag);
        for (var k in attrs)
            el.setAttribute(k, attrs[k]);
        return el;
    }

});
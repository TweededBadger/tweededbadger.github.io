define(['./module'], function (directives) {
    'use strict';
    directives.directive('svgPathReplace',
        ['$timeout','$compile',
            function ($timeout,$compile) {
                return {
                    restrict: 'E',
                    link: function (scope, element, attrs) {
                        var path = makeNode('path', element, attrs);
                        var newElement = path.cloneNode(true);
                        $timeout(function() {
                            element.replaceWith(newElement);

                        });
                    }
                }
            }]);


    function makeNode(name, element, settings) {
        var ns = 'http://www.w3.org/2000/svg';
        var node = document.createElementNS(ns, name);
        for (var attribute in settings) {
            var value = settings[attribute];
            if (value !== null && value !== null && !attribute.match(/\$/) &&
                (typeof value !== 'string' || value !== '')) {
                node.setAttribute(attribute, value);
            }
        }
        return node;
    }

});
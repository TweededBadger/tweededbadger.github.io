define(['./module','svg-pan-zoom','county_data'], function (directives,svgPanZoom) {
    'use strict';
    directives.directive('datamodule',
        ['optionsService','$timeout','$compile','$resource','$parse','$location',
            'SpeedtestAverageFilter',
            function (optionsService,$timeout,$compile,$resource,$parse,$location,
                      SpeedtestAverageFilter) {
                return {
                    restrict: 'A',
                    templateUrl: optionsService.assetUrl+"templates/data_table_module.html",
                    link: function (scope, element, attrs) {
                        scope.currentRegion = "UK";
                        scope.countyByCountry = countyByCountry;
                        scope.$on('loadNewData', function (e,msg) {
                            loadRegionData(msg.county);
                        });
                        scope.$watch('selectedCounty',function(newval,oldval){
                            console.log(newval);
                            if (!angular.isUndefined(newval))loadRegionData(newval);
                        });
                        scope.scrollToGrades = function($event) {
                            window.scrollTo(0, 1000);
                            $event.preventDefault();
                        }

                        var loadRegionData = function(region) {
                            scope.currentRegion = region;
                            scope.regionData = SpeedtestAverageFilter.query(
                                {
                                    order_by: 'provider',
                                    arg1:"/"+region
                                }, function (data) {
                                });
                        }
                        scope.regionData = SpeedtestAverageFilter.query(
                            {order_by: 'provider'
                            }, function (data) {
                            });

                        if ($location.search().c) {
                            var county = $location.search().c;
                            loadRegionData(county);
                        }
                    }
                }
            }]);


});
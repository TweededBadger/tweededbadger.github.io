define([
    './map',
    './data-table',
    './svgPathReplace'
], function () {});

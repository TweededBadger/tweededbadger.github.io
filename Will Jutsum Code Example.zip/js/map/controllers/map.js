define(['./module'], function (controllers) {
    'use strict';
    controllers.controller('MapCtrl', ['$scope','$location','optionsService',
        function ($scope,$location,optionsService) {
            $scope.assetUrl = optionsService.assetUrl;
            $scope.regionClickCallback = function(data) {
                $location.search('c', data.county);
                $scope.$broadcast('loadNewData', data);
                $scope.showingintro = false;
            }

            if ($location.search().c) {
                $scope.showingintro = false;
            } else {
                $scope.showingintro = true;
            }



    }]);
});

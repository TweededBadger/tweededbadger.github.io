define([
    './speedtest_filters.min'
], function () {});

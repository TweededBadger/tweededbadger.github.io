define([
    'angular',
    'angular-route'
], function (angular) {

    angular.module('speedtestFilters', []).filter('grade', [function () {
        return function (input, grades) {
            if (grades.length == 0) return "";
            var returnval = false;
            angular.forEach(grades, function (value, key) {
                if (input > value.limit_lower && input < value.limit_upper) {
                    returnval = value.grade_text;
                }
            });
            if (returnval) {
                return returnval;
            } else {
                return grades[0].grade_text;
            }
        };
    }]).filter('comparison', ['$filter',function ($filter) {
        return function (input, size,short) {
            var filekb = size * 1024;
            var speedkb = input * 125;
            var result = (filekb / speedkb) * 1000;
            var filtered = "";
            if ((result / 1000) < 60) {
                filtered = $filter('date')(result, "s 'seconds'");
                if (short) filtered = $filter('date')(result, "s's'");
            } else if (Math.floor((result / 1000) / 60) == 1) {
                filtered = $filter('date')(result, "m 'minute and' s 'seconds'");
                if (short) filtered = $filter('date')(result, "m'm' s's'");
            } else {
                filtered = $filter('date')(result, "m 'minutes and' s 'seconds'");
                if (short) filtered = $filter('date')(result, "m'm' s's'");
            }
            return filtered;
        };
    }]).filter('grade_color', [function () {
        return function (input, grades) {
            if (grades.length == 0) return "#F4F4F4";

            var colors = {
                A:"#ff0000",
                B:"#ffFF00",
                C:"#ff00FF",
                D:"#00FF00",
                E:"#ff0000",
                F:"#ff0000"
            }

            angular.forEach(grades, function (value, key) {
                if (input > value.limit_lower && input < value.limit_upper) {
                    returnval = value.grade_text;
                }
            });
            if (returnval) {
                return colors[returnval];
            } else {
                return "#cccccc"
            }
        }
    }])
        .filter('grade_map_color', [function () {
        return function (input, grades,speedData) {
            if (grades.length == 0 || speedData.length == 0) return "#F4F4F4";

            var colors = {
                A:"#ff0000",
                B:"#ffFF00",
                C:"#ff00FF",
                D:"#00FF00",
                E:"#ff0000",
                F:"#ff0000"
            }
            var download_speed = 0;
            if (grades.length == 0) return "";
            var returnval = false;
            angular.forEach(speedData, function (value, key) {
                if (input == value.location_county) {
                    download_speed = value.result_download__avg;
                }
            });

            angular.forEach(grades, function (value, key) {
                if (download_speed > value.limit_lower && download_speed < value.limit_upper) {
                    returnval = value;
                }
            });
            if (returnval) {
                return returnval.colour;
            } else {
                return "#F4F4F4"
            }
        };
    }]);
});
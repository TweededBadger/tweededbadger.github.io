require.config({

    paths: {
        'angular': '//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular.min',
        'angular-route': '//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular-route.min',
        'angular-cookies': '//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular-cookies.min',
        'angular-resource': '//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular-resource.min',
//        'angular-animate': '../bower_components/angular-animate/angular-animate',
        'domReady': '../lib/requirejs-domready/domReady',
        'async': '../bower_components/requirejs-plugins/src/async',
        'd3':'//cdnjs.cloudflare.com/ajax/libs/d3/3.4.1/d3.min',
        'simple-statistics':'../lib/simple_statistics.min',
        'ua-parser':'../bower_components/ua-parser-js/src/ua-parser.min',
        'polyfills':'./utils/polyfills.min',
        'testingUtils':'./utils/testingUtils.min',
        'require-css':'../bower_components/require-css/css',
        'jquery':'//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min',
        'bootstrapjs':'//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min',
        'view_speedtest':'../views/view_speedtest/view_speedtest.min'
    },
    shim: {
        'angular': {
            exports: 'angular'
        },
        'angular-route': {
            deps: ['angular']
        },
        'angular-cookies': {
            deps: ['angular']
        },
        'angular-resource': {
            deps: ['angular']
        },
        'bootstrapjs':{
            deps: ['jquery']
        }
//        ,
//        'angular-animate': {
//            deps: ['angular']
//        }
    },

    deps: [
        './bootstrap'
    ],
    map: {
        '*': {
            'css':'require-css'
        }
    }
});

define([
    'angular',
    'angular-route',
    'angular-cookies',
    'angular-touch',
//    'angular-animate',
    'view_map',
    './map/controllers/index',
    './map/directives/index',
    './filters/index',
    './services/index',
    'css!../css/main.min',
    'jquery',
    'bootstrapjs'
], function (angular) {
'use strict';
// Declare app level module which depends on views, and components
return angular.module('SpeedtestApp', [
  'SpeedtestApp.view_map',
  'speedTestControllers',
  'speedTestMapDirectives',
//    'speedTestDirectives',
    'speedTestServices',
    'speedtestFilters',
    'ngRoute',
    'ngCookies',
    'ngTouch'
//    ,
//    'ngAnimate'
])


});


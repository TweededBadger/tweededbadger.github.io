define(['./module', 'd3', 'simple-statistics'], function (services, d3) {
    'use strict';
    services.service('speedTestingService', ['SingleTest', 'Graph', 'TestBatch', '$timeout', '$rootScope', 'optionsService',
        function (SingleTest, Graph, TestBatch, $timeout, $rootScope, optionsService) {
            var downloadTestFiles = [
//            "http://mitchell.netdnase17.netdna-cdn.com/testing/100mb.test"
//            "http://speedtest-testapp.appspot.com/testfiles/testfile.zip"
                "http://speedtest.consumerchoices.co.uk/random4000x4000.jpg"
//            "http://cachefly.cachefly.net/100mb.test"
//            "http://bucket.cdndtl.co.uk/SpeedTesterImages/random4000x4000.jpg"
            ];
            var currentTestFile = optionsService.downloadTest;
            var allowTesting = true;
            var currentTest = {};
            var currentTestBatch = {};
            var triggerSpeed = 0;
            var testsRun = 0;
            var graph = false;
            var totalDataDownloaded = 0;
            var currentTimeoutPromise;

            $rootScope.testNumber = 1;

            var options = {
                testsPerBatchDownload: optionsService.testsPerBatchDownload,
                testsPerBatchUpload: optionsService.testsPerBatchUpload,
                testTimeLimit: optionsService.testTimeLimit
            }


            $rootScope.totaltests = options.testsPerBatchDownload + options.testsPerBatchUpload;
            var currentRequest = new XMLHttpRequest();

            var currentTestType = 'download';

            var startNewTestBatch = function (type) {
                currentTestType = type;
                if (!allowTesting) return;
                allowTesting = false;
                currentTestBatch = new TestBatch(type);
                testsRun = 0;
                totalDataDownloaded = 0;
                startTest();
            }
            var finishTestBatch = function () {
                var results = currentTestBatch.getResult();
                allowTesting = true;
                console.log(totalDataDownloaded);
                results.dataTransfered = totalDataDownloaded;
                $rootScope.$broadcast('testFinished', results);
//            console.log(currentTestBatch);
            }


            function createCORSRequest() {
                var xhr = new XMLHttpRequest();
                if ("withCredentials" in xhr) {
                    //xhr.open(method, url, true);

                } else if (typeof XDomainRequest != "undefined") {
                    xhr = new XDomainRequest();
                    //xhr.open(method, url);
                } else {
                    xhr = null;
                }
                return xhr;
            }

            var startTest = function () {
                if (!graph) graph = new Graph();
                triggerSpeed = 0;
                currentRequest = createCORSRequest();
                currentRequest.onload = finishEvent;
                currentRequest.onloadstart = startEvent;
                currentRequest.onreadystatechange = stateChangeEvent;
                switch (currentTestType) {
                    case 'download':
                        var imageAddr = currentTestFile + "?n=" + Math.random();
                        currentRequest.onprogress = progressEvent;
                        currentRequest.open("GET", imageAddr, true);
//                    currentRequest.overrideMimeType('text/plain; charset=x-user-defined');
                        currentRequest.send(null);
                        var newtest = new SingleTest();
                        currentTest = newtest;
                        currentTimeoutPromise = $timeout(testTimedOut, options.testTimeLimit * 1000 + 1000);
                        break;
                    case 'upload':
                        var formData = new FormData();
                        formData.append('file', blob, "readme.txt");
//                    currentRequest.withCredentials = true;
                        currentRequest.open("POST", optionsService.uploadTest, true);
                        currentRequest.upload.onprogress = progressEvent;
                        currentRequest.send(formData);
                        var newtest = new SingleTest();
                        currentTest = newtest;
                        currentTimeoutPromise = $timeout(testTimedOut, options.testTimeLimit * 1000 + 1000);
                        break;
                }


            }
            var createUploadBlobData = function (megabytes) {
//            var data = "";
//            var possibleCapitals = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//            var charArray = [];
//            for (var i = 0; i < 1024*1024*megabytes; i++) {
//                //data += 'A';//);
//                //charArray.push(possibleCapitals.charAt(Math.floor(Math.random() * possibleCapitals.length)));
//                charArray[i] = "a";
//            }
                var blob = new Blob([new Array(1024 * 1024 * megabytes).join('0')], {type: 'plain/text'});
                return blob;
            }
            var blob = createUploadBlobData(20);
            var forceStop = function () {
                currentRequest.abort();
                allowTesting = true;
            }
            var saveTest = function (e) {
                currentTest.save();
                testsRun++;
                $rootScope.$apply(function () {
                    $rootScope.testNumber++;
                });

                currentTestBatch.tests.push(currentTest);
                if (
                    (currentTestType == "download" && testsRun == options.testsPerBatchDownload) ||
                    (currentTestType == "upload" && testsRun == options.testsPerBatchUpload)

                ) {
                    finishTestBatch();
                } else {
                    $timeout(startTest, 200);
                }
            }
            var stateChangeEvent = function (e) {
//                console.log("stateChangeEvent");
//                console.log(e);
            }
            var testTimedOut = function (e) {
                console.log("TEST TIMED OUT");
                currentRequest.abort();
                saveTest();
            }
            var progressEvent = function (e) {
                //scope.$apply(function(){
                currentTest.loadedPercentage = ((e.loaded / e.total) * 100).toFixed(2);
                currentTest.downloadSize = e.total;
                var now = new Date().getTime();
//            var now = e.timeStamp;
                var bytesDiff = (e.loaded - currentTest.lastProgressBytes) * 8;
                var timeDiff = (now - currentTest.lastProgressTime) / 1000;
                currentTest.currentDownloadSpeed = ((bytesDiff / timeDiff) / 1024 / 1024);//.toFixed(2);
                if (isNaN(currentTest.currentDownloadSpeed)) currentTest.currentDownloadSpeed = 0;
                currentTest.lastProgressTime = now;
                currentTest.lastProgressBytes = e.loaded;
                currentTest.progressSpeeds.push(currentTest.currentDownloadSpeed);
                currentTest.totalTime = now - currentTest.startTime;
                currentTest.update();
                graph.addData([currentTest.movingAverageValues,
                    currentTest.totalAverage,
                    currentTest.variances,
                    currentTest.progressSpeeds]);
                if (currentTest.totalTime > 2000 && currentTest.standardDeviation < currentTest.movingAverage * 0.035) {
                    if (triggerSpeed == 0) {
                        triggerSpeed = currentTest.movingAverage;
                        currentTest.triggerSpeed = currentTest.movingAverage;
                        totalDataDownloaded += e.loaded;
                        currentRequest.abort();
                        $timeout.cancel(currentTimeoutPromise);
                        saveTest();
                    }
                } else if (currentTest.totalTime > options.testTimeLimit * 1000) {
                    console.log("hit time limit");
                    if (triggerSpeed == 0) {
                        triggerSpeed = currentTest.movingAverage;
                        currentTest.triggerSpeed = currentTest.movingAverage;
                        totalDataDownloaded += e.loaded;
                        currentRequest.abort();
                        $timeout.cancel(currentTimeoutPromise);
                        saveTest();
                    }
                }

            }
            var startEvent = function (e) {
            }
            var finishEvent = function (e) {
                totalDataDownloaded += e.loaded;
                saveTest();
                allowTesting = true;
            }
            return {
                get allowTesting() {
                    return allowTesting;
                },
                get currentTest() {
                    return currentTest;
                },
                get currentTestBatch() {
                    return currentTestBatch;
                },
                startNewTestBatch: startNewTestBatch
            }
        }])
        .factory('SingleTest', function () {
            var SingleTest = function () {
                this.startTime = (new Date()).getTime();
                this.loadedPercentage = 0;
                this.lastProgressTime = this.startTime;
                this.lastProgressBytes = 0;
                this.topSpeed = 0;
                this.progressSpeeds = [];
                this.movingAverageValues = [];
                this.totalAverage = [];
                this.variances = [];
                this.mean = 0;
                this.movingAverage = 0;
                this.standardDeviation = 9999;
                this.realAverage = 0;
                this.triggerSpeed = 0;
                this.totalTime = 0;
                this.type = "";
            }
            SingleTest.prototype.save = function () {
                var self = this;
                var minVariance = ss.min(self.variances.slice(1, Math.max(self.variances.length - 1, 1)));
                self.movingAverage = self.movingAverageValues[self.variances.indexOf(minVariance)];
                if (typeof self.movingAverage === "undefined") self.movingAverage = 0.00001;
                console.log(self.movingAverage);
            }
            SingleTest.prototype.update = function () {
                var self = this;
                var lastSpeeds = self.progressSpeeds.slice(Math.max(self.progressSpeeds.length - 20, 0));
                if (self.mean != null) {
                    this.movingAverage = ss.mean(lastSpeeds)
                    self.movingAverageValues.push(this.movingAverage);
                }
                this.standardDeviation = ss.standard_deviation(self.movingAverageValues.slice(Math.max(self.movingAverageValues.length - 10, 0)));
                if (!isNaN(this.standardDeviation)) {
                    self.variances.push(this.standardDeviation)
                    self.mean = ss.mean(self.progressSpeeds);
                    self.totalAverage.push(self.mean);
                    self.realAverage = (this.lastProgressBytes * 8) / (this.lastProgressTime - this.startTime) / 1024;
                } else {
                    debugger;
                }
            }
//        SingleTest.prototype.testFunction = function(){
//            var self = this;
//            return self.test;
//        }
            return SingleTest;
        })
        .factory('TestBatch', function () {
            var TestBatch = function (type) {
                this.tests = [];
                this.type = type;
            }
            TestBatch.prototype.getResult = function () {
                var self = this;
                var results = self.tests.map(function (test) {
                    return test.movingAverage;
                });
                var median = ss.median(results);
                var filteredResults = [];
                results.map(function (result) {
                    if (Math.abs(result - median) <= median * 0.2) filteredResults.push(result);
                })
                return {
                    result: ss.mean(filteredResults),
                    type: self.type
                }
            }
            return TestBatch;
        })

        .factory('Graph', function () {
            var Graph = function () {
                var self = this;
                this.svg = d3.select("#graph")
                    .append("svg:svg")
                    .attr("width", 6000)
                    .attr("height", 200);

                this.x = d3.scale.linear()
                    .range([0, 2]);
                this.y = d3.scale.linear()
                    .domain([0, 100])
                    .range([200, 0]);

                this.data = [];
                this.line = d3.svg.line()
                    .x(function (d, index) {
//                console.log(self.x(d[0]));
                        //console.log(index);
                        return self.x(index);
                        //return index;
                    })
                    .y(function (d) {
                        return self.y(d);
                        //return d;
                    });


//        this.svg.selectAll("circle")
//            .data(this.data)
//            .enter()
//            .append("circle")
//            .attr("cx", function(d) {
//                return d[0];
//            })
//            .attr("cy", function(d) {
//                return d[1];
//            })
//            .attr("r", 5);

                Graph.prototype.addData = function (data) {
                    var self = this;

                    self.y = d3.scale.linear()
                        .domain([0, ss.max(data[0])])
                        .range([200, 0]);
                    self.svg.selectAll('*').remove();
                    for (var i = 0; i < data.length; i++) {
                        var obj = data[i];
                        this.svg.append("path")
                            .datum(obj)
                            .attr("class", "line line" + i)
                            .attr("d", this.line);
                    }
                }

                //self.data = data;


            }
            return Graph;
        })


});
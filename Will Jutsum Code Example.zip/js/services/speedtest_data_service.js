define(['./module'], function (services) {
    'use strict';
    services.factory("Speedtest",
        ['$resource', 'optionsService',
            function ($resource, optionsService) {
                return $resource(optionsService.apiUrl + '/speedtests', {}, {
                    query: {method: 'GET', params: {}, isArray: true},
                    create: { method: 'POST' }
                });
            }])
        .factory("SpeedtestAverage",
        ['$resource', 'optionsService',
            function ($resource, optionsService) {
                return $resource(optionsService.apiUrl  + '/speedtest_average/:lat/:lng/:distance', {}, {
                    query: {method: 'GET', params: {lat: '@lat', lng: '@lat', distance: '@lat'}, isArray: true}
//                create: { method: 'POST' }
                });
            }])
        .factory("SpeedtestAverageFilter",
        ['$resource', 'optionsService',
            function ($resource, optionsService) {
                return $resource(optionsService.apiUrl  + '/speedtest_average/:order_by:arg1', {}, {
                    query: {method: 'GET', params: {order_by: '@order_by',arg1:"@arg1"}, isArray: true}
//                create: { method: 'POST' }
                });
            }])
        .factory("CompetitionEntry",
        ['$resource', 'optionsService',
            function ($resource, optionsService) {
                return $resource(optionsService.apiUrl  + '/competition', {}, {
//                query: {method:'GET', params:{}, isArray:true},
                    create: { method: 'POST' }
                });
            }])
});
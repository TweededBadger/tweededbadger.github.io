define(
    ['./module','jquery','testingUtils','ua-parser',
        'async!http://maps.google.com/maps/api/js?sensor=false'
    ],
    function (services,$) {
    'use strict';
    services.service("userDataService",
        ['$interval', '$resource','$timeout', 'optionsService',
            function ($interval, $resource,$timeout,optionsService) {
                var self = this;
                var parser = new UAParser();
                var geoDataToCollect = ["postal_town", "administrative_area_level_2", "country", "postal_code_prefix"];
                var geoDataNames = ["postal_town", "county", "country", "postal_code_prefix"];
                var userAgentData = parser.getResult();
                var locationData = {};
                var geoData = {};
                var requiredGeoData = {};
                var firstRun = true;
                var testing = false;
                var connectionInfoLoop = false;

                self.locationDataCallback = false;
                this.registerLocationCallback = function (callback) {
                    self.locationDataCallback = callback;
                }
                var providersResource = $resource(optionsService.apiUrl + '/providers///');
                var providers = providersResource.query(function (d) {
                });
                var connectionTypesResource = $resource(optionsService.apiUrl + '/connectiontypes/');
                var connectionTypes = connectionTypesResource.query();
                var connectionInfoResource = $resource(optionsService.apiUrl + '/connection_info?:rand', {rand:'@rand'});
                var connectionInfo = connectionInfoResource.get({rand:Math.random()},function (data) {
                    if (data.user_type != 'cellular') {
                        $('#residential-modal').modal({show: true,backdrop:'static'});
                        startConnectionInfoPollLoop();
                        $('#residential-modal').on('hidden.bs.modal', function (e) {
                            connectionInfoLoop = false;
                        })

                    }
                });
                var gradesResource = $resource(optionsService.apiUrl + '/grades');
                var grades = gradesResource.query();
                if (testing) {
                    var testinglatlng = testingUtils.randomLatLng();
                }

                var startConnectionInfoPollLoop = function() {
                    connectionInfoLoop = true;
                    connectionInfoPoll();
                }

                var connectionInfoPoll = function() {
                    if (connectionInfoLoop) {
                        connectionInfo = connectionInfoResource.get({rand:Math.random()},function (data) {
                            if (data.user_type != 'cellular') {
                                $timeout(connectionInfoPoll, 1000);
                            } else {
                                connectionInfoLoop = false;
                                $('#residential-modal').modal('hide');
                            }
                        },function(responce) {
                            console.log(responce);
                            $timeout(connectionInfoPoll, 1000);
                        });
                    }
                }

                var updateLocation = function () {
                    navigator.geolocation.getCurrentPosition(function (data) {
                        locationData = data;
                        if (firstRun) {
                            updateGeoData();
                            firstRun = false;
                        }
                    },
                    function(err) {
                        console.log(err);
                        console.log(err.code);
                    });
                }
                var updateGeoData = function () {
                    if (testing) {
                        var latlng = testinglatlng;
                    } else {
                        var latlng = new google.maps.LatLng(locationData.coords.latitude, locationData.coords.longitude);
                    }
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latlng}, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[1]) {
                                geoData = results;

                                updateRequiredGeoData();
                            } else {
                                console.log("No results found");
                            }
                        } else {
                            console.log("Geocode failed: " + status);
                        }
                    });
                }
                var updateRequiredGeoData = function () {
                    requiredGeoData = {};
                    if (testing) {
                        requiredGeoData.latitude = testinglatlng.lat();
                        requiredGeoData.longitude = testinglatlng.lng();
                        requiredGeoData.location_accuracy = 0;
                    } else {
                        requiredGeoData.latitude = locationData.coords.latitude;
                        requiredGeoData.longitude = locationData.coords.longitude;
                        requiredGeoData.location_accuracy = locationData.coords.accuracy;
                    }
                    angular.forEach(geoData, function (value, key) {
                        angular.forEach(value.address_components, function (component_value, key) {
                            angular.forEach(geoDataToCollect, function (dataToCollect, key2) {
                                if (requiredGeoData[dataToCollect] == undefined) {
                                    if (component_value.types.indexOf(dataToCollect) != -1) {
                                        requiredGeoData[geoDataNames[key2]] = component_value.long_name;
//                                if (Object.keys(requiredGeoData).length == geoDataToCollect.length) {
//
//                                }
                                    }
                                }

                            });
                        });
                        //this.push(key + ': ' + value);

                    });

                    if (self.locationDataCallback) {
                        self.locationDataCallback(requiredGeoData);
                    }
                    console.log(requiredGeoData);
                }
                if (navigator.geolocation) {
                    //$interval(updateLocation, 1000);
                    updateLocation();
                } else {
                    console.log("No Geolocation")
                }
                return {
                    userAgentData: userAgentData,
                    registerLocationCallback:this.registerLocationCallback,
                    get locationData() {
                        return locationData;
                    },
                    get geoData() {
                        return geoData;
                    },
                    get requiredGeoData() {
                        return requiredGeoData;
                    },
                    get providers() {
                        return providers;
                    },
                    get connectionInfo() {
                        return connectionInfo;
                    },
                    get connectionTypes() {
                        return connectionTypes;
                    },
                    get grades() {
                        return grades;
                    },
                    test: function () {
                        return userAgentData;
                    }
                }
            }])
});
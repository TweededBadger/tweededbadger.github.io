define(['./module'], function (services) {
    'use strict';
    services.service('optionsService', [
        function ($rootScope) {
            return {
                apiUrl:'http://mobilespeedtest.broadbandchoices.co.uk',
                assetUrl:'http://mobilespeedtest.broadbandchoices.co.uk/static/'
            }

        }
        ]);
});

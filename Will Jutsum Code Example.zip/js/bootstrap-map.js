
define([
    'require',
    'angular',
    'app-map',
    'routes-map'
], function (require, ng) {
    'use strict';
    require(['domReady!'], function (document) {
        ng.bootstrap(document, ['SpeedtestApp']);
        //alert("We are ready!");
    });
});

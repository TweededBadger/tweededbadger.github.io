require.config({

    paths: {
        'angular': '//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-rc.3/angular.min',
        'angular-route': '//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-rc.3/angular-route.min',
        'angular-cookies': '//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-rc.3/angular-cookies.min',
        'angular-resource': '//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-rc.3/angular-resource.min',
        'angular-touch': '//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-rc.3/angular-touch.min',
//        'angular-animate': '../bower_components/angular-animate/angular-animate',
        'domReady': '../lib/requirejs-domready/domReady',
        'async': '../bower_components/requirejs-plugins/src/async',
        'd3':'//cdnjs.cloudflare.com/ajax/libs/d3/3.4.1/d3.min',
        'simple-statistics':'../lib/simple_statistics.min',
        'ua-parser':'../bower_components/ua-parser-js/src/ua-parser.min',
        'polyfills':'./utils/polyfills.min',
        'testingUtils':'./utils/testingUtils.min',
        'require-css':'../bower_components/require-css/css',
        'jquery':'//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min',
        'bootstrapjs':'//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min',
        'svg-pan-zoom':'../lib/svg-pan-zoom/svg-pan-zoom',
        'view_map':'../views/view_map/view_map',
        'county_data':'./map/county_data'
    },
    shim: {
        'angular': {
            exports: 'angular'
        },
        'angular-route': {
            deps: ['angular']
        },
        'angular-cookies': {
            deps: ['angular']
        },
        'angular-resource': {
            deps: ['angular']
        },
        'angular-touch': {
            deps: ['angular']
        },
        'bootstrapjs':{
            deps: ['jquery']
        }
//        ,
//        'angular-animate': {
//            deps: ['angular']
//        }
    },

    deps: [
        './bootstrap-map'
    ],
    map: {
        '*': {
            'css':'require-css'
        }
    }
});

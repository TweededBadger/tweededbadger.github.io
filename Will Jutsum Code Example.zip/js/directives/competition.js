define(['./module'], function (directives) {
    'use strict';
    directives.directive('competitionModule',
        ['CompetitionEntry','optionsService', function (CompetitionEntry,optionsService) {
            return {
                restrict: 'A',
//            scope:true,
                templateUrl: optionsService.assetUrl+"templates/competition_module.html",
                link: function (scope, element, attrs,ctrl) {
                    console.log(ctrl);
                    scope.enteredCompetition = false;
                    scope.inputNewsletter = false;
                    scope.validateForm = function() {
                        //if (ctrl.inputEmail.length > 2) return true;
                        if (!scope.competitionForm.inputEmail.$viewValue) return false;
                        if(!scope.competitionForm.inputEmail.$valid) return false;
                        if (!scope.competitionForm.inputTerms.$valid) return false;

                        return true;
                    };
                    scope.submitForm = function () {
                        scope.enteredCompetition = true;
                        var compData = {
                            "name": "",
                            "email": scope.inputEmail,
                            "newsletter": 1,
                            "speedtest":scope.savedTest.id
                        }
                        CompetitionEntry.create(compData, function (d) {
                            console.log(d);
                            setTimeout(function() {
                                window.location.replace("http://www.broadbandchoices.co.uk/");
                            },3000);

                        });
                    }
                }
            }
        }]);

});

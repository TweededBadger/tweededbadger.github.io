define(['./module'], function (directives) {
    'use strict';
    directives.directive('speedtestModule',
        ['SingleTest', 'Graph', 'TestBatch', '$timeout', '$parse', 'speedTestingService','optionsService',
            function (SingleTest, Graph, TestBatch, $timeout, $parse, speedTestingService,optionsService) {
                return {
                    restrict: 'A',
//            scope:true,
                    templateUrl: optionsService.assetUrl+"templates/speedtest_module.html",

                    link: function (scope, element, attrs) {

                        var ctrlResultsFn = $parse(attrs.ctrlResultsFn);

                        scope.$watch(function () {
                            scope.currentTest = speedTestingService.currentTest;
                            scope.currentTestBatch = speedTestingService.currentTestBatch;
                            scope.allowTesting = speedTestingService.allowTesting;
                        });
                        scope.$on('startTest', function (e, type) {
                            speedTestingService.startNewTestBatch(type);
                        });
                        scope.$on('testFinished', function (e, data) {
                            ctrlResultsFn(scope, {data: data});
                        });
                        scope.sttest = function () {
                            ctrlResultsFn(scope, {data: "hello there"});
                        }
                        scope.startTests = function (type) {
                            speedTestingService.startNewTestBatch(type);
                        }


                    }
                }
            }]);
});
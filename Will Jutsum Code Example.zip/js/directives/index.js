define([
    './competition',
    './sharing',
    './speedtest'
], function () {});
